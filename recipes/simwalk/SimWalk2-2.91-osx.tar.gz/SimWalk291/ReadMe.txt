   
              Distribution Information for SimWalk2 version 2.91
   
   
Thank you for your interest in the SimWalk2 package.
   
SimWalk2 is a statistical genetics application that uses
Markov chain Monte Carlo and simulated annealing algorithms
to analyze any size pedigrees.
   
SimWalk2 performs the following types of multipoint analyses:
haplotyping, parametric linkage (LOD, location scores),
non-parametric linkage (NPL, allele sharing statistics),
identity by descent (IBD), and mistyping.
   
This file describes how to obtain the files included in this package.
Please see the file DOCS/SimWalk2.html for the main user documentation.
   
The home sites for SimWalk2 are <http://watson.hgen.pitt.edu/register> and
<http://www.genetics.ucla.edu/software>. The latest executables, source code,
documentation and example files can be obtained from these sites in integrated,
compressed packages. See below for sample instructions for decompressing these
files.
   
The packages available for downloading are named to correspond to the
Operating System and CPU under which the included executable will run:
1) SimWalk291_lin_intel.tar.gz : executable for Linux (any version) using i32
2) SimWalk291_mac_g4-g5.tar.gz : executable for Mac OS X (v10.2 + ) using G4/G5
3) SimWalk291_osf_alpha.tar.gz : executable for OSF/Tru64 (v5.0 + ) using Alpha
4) SimWalk291_sun_sparc.tar.gz : executable for Solaris (v2.5 + )   using Sparc
5) SimWalk291_win_intel.zip :    executable for Windows (Win 2K + ) using i32
Here i32 means any Pentium-compatible CPU.
   
Expanding any of these packages will result in a directory called SimWalk291.
SimWalk291 will contain the directories CODE, DOCS, and Examples. Also within
SimWalk291 will be this file (ReadMe.txt), the file WhatsNew_291.txt, and
the SimWalk2 executables. There are two executables included in the package:
simwalk2snp is set up for data sets containing many biallelic markers;
simwalk2 is the "normal" executable for general data sets.
   
In the DOCS subdirectory you will find this file (ReadMe.txt) and
the html-based documentation files. To read the documentation,
please use your favorite brower to open index.html or SimWalk2.html,
either file will work.
   
In the CODE subdirectory you will find the following text documents:
 1) simwalk2.f   : the main source code file for SimWalk2
 2) nomendel.f   : a secondary source code file used by SimWalk2
 3) Compile.txt  : a short list of suggestions for compiling SimWalk2
 4) make.sw2.csh : a Unix c-shell script to compile SimWalk2 using g77
                   (this is not a proper Unix "make" file, just a shell script)
   
In the Examples subdirectory you will find the following text documents:
 1) MAP.DAT, LOCUS.DAT, PEDIGREE.DAT and PEN.DAT are the input data files
    for the example analyses exhibited here. The data originates from a
    study of episodic ataxia (EA) by Litt et al. (Am J Hum Gen 55:702-709).
 2) BATCH-xx.DAT files contain the control parameters that instruct simwalk2
    how each run should proceed. To duplicate one of these example analyses
    simply rename the corresponding BATCH-xx.DAT to BATCH2.DAT and run simwalk2.
    BATCH-01.DAT : -> sampling analysis
    BATCH-11.DAT : -> haplotype analysis
    BATCH-22.DAT : -> parametric linkage analysis (i.e., location scores)
    BATCH-33.DAT : -> non-parametric linkage analysis (i.e., sharing statistics)
    BATCH-44.DAT : -> identity-by-descent (IBD) analysis
    BATCH-55.DAT : -> mistyping analysis
 3) The remaining files are a selection of the output files from these example
    analyses. All output filenames include a label indicated in the
    corresponding control file, e.g., SCORE-22.ALL is the output of the
    location score analysis initiated by the control file BATCH-22.DAT.
    The user documentation describes the content of all these files.
   
   
Many downloading utilities will automatically expand the files. If needed,
the ".tar.gz" files can be natively expanded by most archiving utilities, e.g.,
WinZip and Stuffit Expander. On Unix two commands in sequence will suffice:
to expand, for example, ABC.tar.gz, issue the command 'gunzip ABC.tar.gz' and
then 'tar -xvf ABC.tar'. You may then delete the file ABC.tar. (If you have the
GNU version of tar, the single command 'tar -xvfz ABC.tar.gz' will suffice.)
   
All the files, except the executables, are plain text (also known as ASCII)
documents and are best viewed using a monospaced font (in which every character
occupies the same amount of horizontal space), e.g., Courier. Of course
the executables are binary files.
   
[The text files within the archives may be Unix files, i.e., with LF as the
end-of-line character. Usually the expansion utility will automatically convert
a text file to the local format, e.g., CRLF on Windows. If the text files appear
strange (all on one line, every other line blank, or not left-justified), then
use one of the *many* utilities to convert the text file to your local format.]
   
On Unix, after downloading and decompressing an executable version of SimWalk2
or the make.sw2.csh shell script, one may need to inform the System that the
file is executable. This can be accomplished, for example, by issuing the
command 'chmod a+x <filename>', where <filename> is replaced by either
'simwalk2' or 'make.sw2.csh'.
   
All posted executables are capable of all analyses. If a new executable is
required, e.g., for a different platform, one may recompile the source code
files which are ANSI Fortran 77. Please see the file Compile.txt for
specific compiling instructions. We would be interested in hearing about
any successes or problems porting the source code to different platforms.
(Compiling has been successful on all known platforms, given sufficient RAM.)
   
When the source code files are recompiled, the resulting executable is
capable of all analyses except location scores. Location score analysis
requires the additional general pedigree analysis package MENDEL
version 3.35 (NOT version 4.0 or later). Please see the documentation for
information on obtaining MENDEL. If the MENDEL code is present, the script
make.sw2.csh will create an executable capable of all analysis options.
   
In general, for any questions, suggestions or comments please contact
either <simwalk@mednet.ucla.edu> or <dweeks@watson.hgen.pitt.edu>.
In particular, we are maintaining a user e-mail list, so if you
use SimWalk2 or wish to hear about future versions of SimWalk2
and you did not sign up for our e-mail list when downloading this package,
then please register by sending e-mail to <simwalk@mednet.ucla.edu>.
(We will never give your e-mail address to anyone and we send out
very few announcements.)
   
Again, thank you for your interest and we welcome your feedback.
   
